create database toysgroup;
use toysgroup; 
CREATE TABLE Product (
    ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Category VARCHAR(50)
);

CREATE TABLE Region (
    ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Country VARCHAR(100)
);
INSERT INTO Product (ID, Name, Category) VALUES
(1, 'Action Figure', 'Toys'),
(2, 'LEGO Set', 'Building Blocks'),
(3, 'Doll', 'Toys');

-- Inserimento dati per la tabella Region
INSERT INTO Region (ID, Name, Country) VALUES
(1, 'North America', 'USA'),
(2, 'Europe', 'Italy'),
(3, 'Asia', 'China');

-- Inserimento dati per la tabella Sales
INSERT INTO Sales (ID, Product_ID, Region_ID, Sale_Date, Amount) VALUES
(1, 1, 1, '2023-01-15', 50.00),
(2, 2, 2, '2023-02-20', 100.00),
(3, 3, 3, '2023-03-25', 75.00),
(4, 1, 2, '2023-04-10', 40.00),
(5, 2, 1, '2023-05-05', 120.00),
(6, 3, 3, '2023-06-15', 80.00);

CREATE TABLE Sales (
    ID INT PRIMARY KEY,
    Product_ID INT,
    Region_ID INT,
    Sale_Date DATE,
    Amount DECIMAL(10, 2),
    FOREIGN KEY (Product_ID) REFERENCES Product(ID),
    FOREIGN KEY (Region_ID) REFERENCES Region(ID)
);
SELECT r.Country, YEAR(s.Sale_Date) AS Sale_Year, SUM(s.Amount) AS Total_Revenue
FROM Region r
JOIN Sales s ON r.ID = s.Region_ID
GROUP BY r.Country, YEAR(s.Sale_Date)
ORDER BY YEAR(s.Sale_Date), Total_Revenue DESC;
--Approccio 1: Utilizzando LEFT JOIN e NULL:
SELECT p.*
FROM Product p
LEFT JOIN Sales s ON p.ID = s.Product_ID
WHERE s.ID IS NULL;
-- provo approccio 2 con not in 
SELECT *
FROM Product
WHERE ID NOT IN (SELECT DISTINCT Product_ID FROM Sales);
-- elenco prodotti con ultima data di vendita
SELECT p.Name AS Product_Name, MAX(s.Sale_Date) AS Last_Sale_Date
FROM Product p
LEFT JOIN Sales s ON p.ID = s.Product_ID
GROUP BY p.Name;

